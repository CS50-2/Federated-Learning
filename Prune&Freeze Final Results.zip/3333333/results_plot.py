"""
This code is used to run the visualisation of the main4 part of the main code, which needs to be run after running main4 and storing the splices in the federated_results folder.
The result of the run is a visualisation of the model aggregation effect for a fixed number of rounds.
You can set the maximum number of rounds for visualisation by modifying MAX_ROUNDS.
"""


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os

def flatten_scalar(x):
    if isinstance(x, list) and len(x) == 1:
        return x[0]
    return x
def prepend_zero_sum(time_list, acc_list):
    acc_list = list(acc_list)  # 把 pandas.Series 转成 list
    min_len = min(len(time_list), len(acc_list))
    x = [0] + list(np.cumsum(time_list[:min_len]))
    y = [0] + acc_list[:min_len]
    return x, y

def prepend_zero(time_list, acc_list):
    acc_list = list(acc_list)  # 把 pandas.Series 转成 list
    min_len = min(len(time_list), len(acc_list))
    x = [0] + time_list[:min_len]
    y = [0] + acc_list[:min_len]
    return x, y

def main():
    load_dir = "federated_results"
    MAX_ROUNDS = 300  # 可视化的最大轮数
    # 原始 FLOPs 总量是 500 轮，现在缩放为 300 轮
    FLOPS_SCALE = MAX_ROUNDS / 500  # 0.6 if MAX_ROUNDS=300

    # 定义通用读取函数
    def load_metric(name):
        path = os.path.join(load_dir, f"{name}.csv")
        if os.path.exists(path):
            return pd.read_csv(path)[name].tolist()
        else:
            print(f"Warning: {name}.csv not found!")
            return []

    # 准备读取变量
    acc_grc = load_metric("acc_grc")[:MAX_ROUNDS]
    acc_grc_smooth = load_metric("acc_grc_smooth")[:MAX_ROUNDS]
    comm_grc = load_metric("comm_grc")[:MAX_ROUNDS]
    flops_grc = load_metric("flops_grc")
    parameters_grc = load_metric("parameters_grc")
    time_rounds_grc = load_metric("time_rounds_grc")[:MAX_ROUNDS]
    time_grc = load_metric("time_grc")[:MAX_ROUNDS]

    acc_grc_freeze_1 = load_metric("acc_grc_freeze_1")[:MAX_ROUNDS]
    acc_grc_freeze_1_smooth = load_metric("acc_grc_freeze_1_smooth")[:MAX_ROUNDS]
    comm_grc_freeze_1 = load_metric("comm_grc_freeze_1")[:MAX_ROUNDS]
    flops_grc_freeze_1 = load_metric("flops_grc_freeze_1")
    parameters_grc_freeze_1 = load_metric("parameters_grc_freeze_1")
    time_rounds_grc_freeze_1 = load_metric("time_rounds_grc_freeze_1")[:MAX_ROUNDS]
    time_grc_freeze_1 = load_metric("time_grc_freeze_1")[:MAX_ROUNDS]

    acc_grc_freeze_2 = load_metric("acc_grc_freeze_2")[:MAX_ROUNDS]
    acc_grc_freeze_2_smooth = load_metric("acc_grc_freeze_2_smooth")[:MAX_ROUNDS]
    comm_grc_freeze_2 = load_metric("comm_grc_freeze_2")[:MAX_ROUNDS]
    flops_grc_freeze_2 = load_metric("flops_grc_freeze_2")
    parameters_grc_freeze_2 = load_metric("parameters_grc_freeze_2")
    time_rounds_grc_freeze_2 = load_metric("time_rounds_grc_freeze_2")[:MAX_ROUNDS]
    time_grc_freeze_2 = load_metric("time_grc_freeze_2")[:MAX_ROUNDS]

    acc_grc_prune_30 = load_metric("acc_grc_prune_30")[:MAX_ROUNDS]
    acc_grc_prune_30_smooth = load_metric("acc_grc_prune_30_smooth")[:MAX_ROUNDS]
    comm_grc_prune_30 = load_metric("comm_grc_prune_30")[:MAX_ROUNDS]
    flops_grc_prune_30 = load_metric("flops_grc_prune_30")
    parameters_grc_prune_30 = load_metric("parameters_grc_prune_30")
    time_rounds_grc_prune_30 = load_metric("time_rounds_grc_prune_30")[:MAX_ROUNDS]
    time_grc_prune_30 = load_metric("time_grc_prune_30")[:MAX_ROUNDS]

    acc_grc_prune_60 = load_metric("acc_grc_prune_60")[:MAX_ROUNDS]
    acc_grc_prune_60_smooth = load_metric("acc_grc_prune_60_smooth")[:MAX_ROUNDS]
    comm_grc_prune_60 = load_metric("comm_grc_prune_60")[:MAX_ROUNDS]
    flops_grc_prune_60 = load_metric("flops_grc_prune_60")
    parameters_grc_prune_60 = load_metric("parameters_grc_prune_60")
    time_rounds_grc_prune_60 = load_metric("time_rounds_grc_prune_60")[:MAX_ROUNDS]
    time_grc_prune_60 = load_metric("time_grc_prune_60")[:MAX_ROUNDS]

    acc_grc_brute_prune = load_metric("acc_grc_brute_prune")[:MAX_ROUNDS]
    acc_grc_brute_prune_smooth = load_metric("acc_grc_brute_prune_smooth")[:MAX_ROUNDS]
    comm_grc_brute_prune = load_metric("comm_grc_brute_prune")[:MAX_ROUNDS]
    flops_grc_brute_prune = load_metric("flops_grc_brute_prune")
    parameters_grc_brute_prune = load_metric("parameters_grc_brute_prune")
    time_rounds_brute_prune = load_metric("time_rounds_brute_prune")[:MAX_ROUNDS]
    time_grc_brute_prune = load_metric("time_grc_brute_prune")[:MAX_ROUNDS]

    acc_grc_brute_prune_smooth = pd.Series(acc_grc_brute_prune).rolling(window=10, min_periods=1).mean()


    labels_grc = [
        "GRA Only",
        "GRA + Freeze 1 Layer",
        "GRA + Freeze 2 Layers",
        "GRA + Prune 30%",
        "GRA + Prune 60%",
        "GRA + Brute Prune",
    ]

    flops_values_grc = [flatten_scalar(v) * FLOPS_SCALE for v in [
        flops_grc,
        flops_grc_freeze_1,
        flops_grc_freeze_2,
        flops_grc_prune_30,
        flops_grc_prune_60,
        flops_grc_brute_prune,
    ]]

    time_values_rounds_grc = [flatten_scalar(sum(v)) for v in [
        time_rounds_grc,
        time_rounds_grc_freeze_1,
        time_rounds_grc_freeze_2,
        time_rounds_grc_prune_30,
        time_rounds_grc_prune_60,
        time_rounds_brute_prune,
    ]]

    time_values_grc = [flatten_scalar(v[-1]) for v in [
        time_grc,
        time_grc_freeze_1,
        time_grc_freeze_2,
        time_grc_prune_30,
        time_grc_prune_60,
        time_grc_brute_prune,
    ]]

    parameter_value_grc = [flatten_scalar(v) * FLOPS_SCALE * 1000 for v in [
        parameters_grc,
        parameters_grc_freeze_1,
        parameters_grc_freeze_2,
        parameters_grc_prune_30,
        parameters_grc_prune_60,
        parameters_grc_brute_prune,
    ]]

    fig, axes = plt.subplots(2, 2, figsize=(14, 12))
    bar_colors = ['skyblue', 'lightgreen','orange', 'salmon']
    metrics = ['FLOPs (TFLOPs)', 'Observation Time (s)', 'Total Time (s)', 'Total Parameter (s)']
    titles = ['FLOPs Comparison', 'Rounds Time Comparison','Total Time Comparison','Total Parameters Comparison']

    grc_values = [flops_values_grc,time_values_rounds_grc ,time_values_grc, [p / 1e3 for p in parameter_value_grc]]

    # 绘制 GRC-based (下排)
    for i in range(4):
        row = i // 2
        col = i % 2
        ax = axes[row][col]
        bars = ax.bar(labels_grc, grc_values[i], color=bar_colors[i % len(bar_colors)])
        for bar in bars:
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2.0, height, f"{height:.2f}", ha='center', va='bottom')
        ax.set_title(titles[i] + " (GRA-based)")
        ax.set_ylabel(metrics[i])
        ax.tick_params(axis='x', rotation=20)
        ax.grid(axis='y', linestyle='--', alpha=0.7)

    plt.tight_layout()
    plt.show()

    plt.tight_layout()
    plt.show()

    # 第一组：原 axes[0, 0] 和 axes[0, 1]
    fig, axes = plt.subplots(1, 2, figsize=(12, 6))
    # axes[0]: Accuracy Over Rounds (GRA)
    axes[0].plot(acc_grc,  label="GRA Only")
    axes[0].plot(acc_grc_freeze_1,  label="GRA + Freeze 1 Layer")
    axes[0].plot(acc_grc_freeze_2,  label="GRA + Freeze 2 Layers")
    axes[0].plot(acc_grc_prune_30,  label="GRA + Prune 30%")
    axes[0].plot(acc_grc_prune_60,  label="GRA + Prune 60%")
    axes[0].plot(acc_grc_brute_prune,  label="GRA + Brute Prune")
    axes[0].set_title("Accuracy Over Rounds (GRA)")
    axes[0].set_xlabel("Rounds")
    axes[0].set_ylabel("Accuracy (%)")
    axes[0].legend()
    axes[0].grid(True)
    # axes[1]: Accuracy vs Communication (GRA)
    axes[1].plot(comm_grc, acc_grc,  label="GRA Only")
    axes[1].plot(comm_grc_freeze_1, acc_grc_freeze_1,  label="GRA + Freeze 1 Layer")
    axes[1].plot(comm_grc_freeze_2, acc_grc_freeze_2,  label="GRA + Freeze 2 Layers")
    axes[1].plot(comm_grc_prune_30, acc_grc_prune_30,  label="GRA + Prune 30%")
    axes[1].plot(comm_grc_prune_60, acc_grc_prune_60,  label="GRA + Prune 60%")
    axes[1].plot(comm_grc_brute_prune, acc_grc_brute_prune,  label="GRA + Brute Prune")
    axes[1].set_title("Accuracy vs Communication (GRA)")
    axes[1].set_xlabel("Comm Count")
    axes[1].set_ylabel("Accuracy (%)")
    axes[1].legend()
    axes[1].grid(True)
    plt.tight_layout()
    plt.show()

    # 第二组：原 axes[1, 0] 和 axes[1, 1]
    fig, axes = plt.subplots(1, 2, figsize=(12, 6))
    axes[0].plot(acc_grc, label="GRA Only", linestyle='--', color='blue', alpha=0.6)
    axes[0].plot(acc_grc_smooth, label="GRA Only (Smoothed)", color='blue')
    axes[0].fill_between(range(len(acc_grc_smooth)), acc_grc_smooth, color='blue', alpha=0.2)
    axes[0].plot(acc_grc_freeze_1, label="GRA + Freeze 1 Layer", linestyle='--', color='orange', alpha=0.6)
    axes[0].plot(acc_grc_freeze_1_smooth, label="GRA + Freeze 1 Layer (Smoothed)", color='orange')
    axes[0].fill_between(range(len(acc_grc_freeze_1_smooth)), acc_grc_freeze_1_smooth, color='orange', alpha=0.2)
    axes[0].set_title("Accuracy Over Rounds (GRA)")
    axes[0].set_xlabel("Rounds")
    axes[0].set_ylabel("Accuracy (%)")
    axes[0].legend()
    axes[0].grid(True)
    axes[1].plot(acc_grc, label="GRA Only", linestyle='--', color='blue', alpha=0.6)
    axes[1].plot(acc_grc_smooth, label="GRA Only (Smoothed)", color='blue')
    axes[1].fill_between(range(len(acc_grc_smooth)), acc_grc_smooth, color='blue', alpha=0.2)
    axes[1].plot(acc_grc_prune_30, label="GRA + Prune 30%", linestyle='--', color='red', alpha=0.6)
    axes[1].plot(acc_grc_prune_30_smooth, label="GRA + Prune 30% (Smoothed)", color='red')
    axes[1].fill_between(range(len(acc_grc_prune_30_smooth)), acc_grc_prune_30_smooth, color='red', alpha=0.2)
    axes[1].set_title("Accuracy Over Rounds (GRA)")
    axes[1].set_xlabel("Rounds")
    axes[1].set_ylabel("Accuracy (%)")
    axes[1].legend()
    axes[1].grid(True)
    plt.tight_layout()
    plt.show()

    # 第三组：原 axes[2, 0] 和 axes[2, 1]
    fig, axes = plt.subplots(1, 2, figsize=(12, 6))
    axes[0].plot(acc_grc_freeze_1, label="GRA + Freeze 1 Layer", linestyle='--', color='orange', alpha=0.6)
    axes[0].plot(acc_grc_freeze_1_smooth, label="GRA + Freeze 1 Layer (Smoothed)", color='orange')
    axes[0].fill_between(range(len(acc_grc_freeze_1_smooth)), acc_grc_freeze_1_smooth, color='orange', alpha=0.2)
    axes[0].plot(acc_grc_freeze_2, label="GRA + Freeze 2 Layers", linestyle='--', color='green', alpha=0.6)
    axes[0].plot(acc_grc_freeze_2_smooth, label="GRA + Freeze 2 Layer (Smoothed)", color='green')
    axes[0].fill_between(range(len(acc_grc_freeze_2_smooth)), acc_grc_freeze_2_smooth, color='green', alpha=0.2)
    axes[0].set_title("Accuracy Over Rounds (GRA)")
    axes[0].set_xlabel("Rounds")
    axes[0].set_ylabel("Accuracy (%)")
    axes[0].legend()
    axes[0].grid(True)
    axes[1].plot(acc_grc_prune_30, label="GRA + Prune 30%", linestyle='--', color='red', alpha=0.6)
    axes[1].plot(acc_grc_prune_30_smooth, label="GRA + Prune 30% (Smoothed)", color='red')
    axes[1].fill_between(range(len(acc_grc_prune_30_smooth)), acc_grc_prune_30_smooth, color='red', alpha=0.2)
    axes[1].plot(acc_grc_prune_60, label="GRA + Prune 60%", linestyle='--', color='purple', alpha=0.6)
    axes[1].plot(acc_grc_prune_60_smooth, label="GRA + Prune 60% (Smoothed)", color='purple')
    axes[1].fill_between(range(len(acc_grc_prune_60_smooth)), acc_grc_prune_60_smooth, color='purple', alpha=0.2)
    axes[1].set_title("Accuracy Over Rounds (GRA)")
    axes[1].set_xlabel("Rounds")
    axes[1].set_ylabel("Accuracy (%)")
    axes[1].legend()
    axes[1].grid(True)
    plt.tight_layout()
    plt.show()

    # 第四组：原 axes[3, 0] 和 axes[3, 1]
    fig, axes = plt.subplots(1, 2, figsize=(12, 6))
    axes[0].plot(acc_grc, label="GRA Only", linestyle='--', color='blue', alpha=0.6)
    axes[0].plot(acc_grc_smooth, label="GRA Only (Smoothed)", color='blue')
    axes[0].fill_between(range(len(acc_grc_smooth)), acc_grc_smooth, color='blue', alpha=0.2)
    axes[0].plot(acc_grc_brute_prune, label="GRA + Brute Prune", linestyle='--', color='olive', alpha=0.6)
    axes[0].plot(acc_grc_brute_prune_smooth, label="GRA + Brute Prune (Smoothed)", color='olive')
    axes[0].fill_between(range(len(acc_grc_brute_prune_smooth)), acc_grc_brute_prune_smooth, color='olive', alpha=0.2)
    axes[0].set_title("Accuracy Over Rounds (GRA)")
    axes[0].set_xlabel("Rounds")
    axes[0].set_ylabel("Accuracy (%)")
    axes[0].legend()
    axes[0].grid(True)
    axes[1].plot(acc_grc_brute_prune, label="GRA + Brute Prune", linestyle='--', color='olive', alpha=0.6)
    axes[1].plot(acc_grc_brute_prune_smooth, label="GRA + Brute Prune (Smoothed)", color='olive')
    axes[1].fill_between(range(len(acc_grc_brute_prune_smooth)), acc_grc_brute_prune_smooth, color='olive', alpha=0.2)
    axes[1].plot(acc_grc_prune_60, label="GRA + Prune 60%", linestyle='--', color='purple', alpha=0.6)
    axes[1].plot(acc_grc_prune_60_smooth, label="GRA + Prune 60% (Smoothed)", color='purple')
    axes[1].fill_between(range(len(acc_grc_prune_60_smooth)), acc_grc_prune_60_smooth, color='purple', alpha=0.2)
    axes[1].set_title("Accuracy Over Rounds (GRA)")
    axes[1].set_xlabel("Rounds")
    axes[1].set_ylabel("Accuracy (%)")
    axes[1].legend()
    axes[1].grid(True)
    plt.tight_layout()
    plt.show()

    # 累积时间 + 加0点
    time_total_1, acc_1 = prepend_zero(time_grc, acc_grc_smooth)
    time_total_2, acc_2 = prepend_zero(time_grc_freeze_1, acc_grc_freeze_1_smooth)
    time_total_3, acc_3 = prepend_zero(time_grc_freeze_2, acc_grc_freeze_2_smooth)
    time_total_4, acc_4 = prepend_zero(time_grc_prune_30, acc_grc_prune_30_smooth)
    time_total_5, acc_5 = prepend_zero(time_grc_prune_60, acc_grc_prune_60_smooth)
    time_total_6, acc_6 = prepend_zero(time_grc_brute_prune, acc_grc_brute_prune_smooth)

    time_round_1, _ = prepend_zero_sum(time_rounds_grc, acc_grc_smooth)
    time_round_2, _ = prepend_zero_sum(time_rounds_grc_freeze_1, acc_grc_freeze_1_smooth)
    time_round_3, _ = prepend_zero_sum(time_rounds_grc_freeze_2, acc_grc_freeze_2_smooth)
    time_round_4, _ = prepend_zero_sum(time_rounds_grc_prune_30, acc_grc_prune_30_smooth)
    time_round_5, _ = prepend_zero_sum(time_rounds_grc_prune_60, acc_grc_prune_60_smooth)
    time_round_6, _ = prepend_zero_sum(time_rounds_brute_prune, acc_grc_brute_prune_smooth)

    fig, axes = plt.subplots(1, 2, figsize=(14, 6))

    # 配色（可自定义）
    colors = {
        'GRA Only': 'tab:blue',
        'Freeze 1': 'tab:orange',
        'Freeze 2': 'tab:green',
        'Prune 30': 'tab:red',
        'Prune 60': 'tab:purple',
        'Brute Prune': 'tab:olive'
    }

    # 左图：Total Training Time
    axes[0].plot(time_total_1, acc_1, label='GRA Only', color=colors['GRA Only'])
    axes[0].fill_between(time_total_1, acc_1, alpha=0.2, color=colors['GRA Only'])

    axes[0].plot(time_total_2, acc_2, label='GRA + Freeze 1 Layer', color=colors['Freeze 1'])
    axes[0].fill_between(time_total_2, acc_2, alpha=0.2, color=colors['Freeze 1'])

    axes[0].plot(time_total_3, acc_3, label='GRA + Freeze 2 Layers', color=colors['Freeze 2'])
    axes[0].fill_between(time_total_3, acc_3, alpha=0.2, color=colors['Freeze 2'])

    axes[0].plot(time_total_4, acc_4, label='GRA + Prune 30%', color=colors['Prune 30'])
    axes[0].fill_between(time_total_4, acc_4, alpha=0.2, color=colors['Prune 30'])

    axes[0].plot(time_total_5, acc_5, label='GRA + Prune 60%', color=colors['Prune 60'])
    axes[0].fill_between(time_total_5, acc_5, alpha=0.2, color=colors['Prune 60'])

    axes[0].plot(time_total_6, acc_6, label='GRA + Brute Prune', color=colors['Brute Prune'])
    axes[0].fill_between(time_total_6, acc_6, alpha=0.2, color=colors['Brute Prune'])

    axes[0].set_title("Accuracy vs Total Training Time")
    axes[0].set_xlabel("Cumulative Total Time (s)")
    axes[0].set_ylabel("Accuracy (%)")
    axes[0].legend()
    axes[0].grid(True)

    # 右图：Round Execution Time
    axes[1].plot(time_round_1, acc_1, label='GRA Only', color=colors['GRA Only'])
    axes[1].fill_between(time_round_1, acc_1, alpha=0.2, color=colors['GRA Only'])

    axes[1].plot(time_round_2, acc_2, label='GRA + Freeze 1 Layer', color=colors['Freeze 1'])
    axes[1].fill_between(time_round_2, acc_2, alpha=0.2, color=colors['Freeze 1'])

    axes[1].plot(time_round_3, acc_3, label='GRA + Freeze 2 Layers', color=colors['Freeze 2'])
    axes[1].fill_between(time_round_3, acc_3, alpha=0.2, color=colors['Freeze 2'])

    axes[1].plot(time_round_4, acc_4, label='GRA + Prune 30%', color=colors['Prune 30'])
    axes[1].fill_between(time_round_4, acc_4, alpha=0.2, color=colors['Prune 30'])

    axes[1].plot(time_round_5, acc_5, label='GRA + Prune 60%', color=colors['Prune 60'])
    axes[1].fill_between(time_round_5, acc_5, alpha=0.2, color=colors['Prune 60'])

    axes[1].plot(time_round_6, acc_6, label='GRA + Brute Prune', color=colors['Brute Prune'])
    axes[1].fill_between(time_round_6, acc_6, alpha=0.2, color=colors['Brute Prune'])

    axes[1].set_title("Accuracy vs Round Execution Time")
    axes[1].set_xlabel("Cumulative Round Time (s)")
    axes[1].set_ylabel("Accuracy (%)")
    axes[1].legend()
    axes[1].grid(True)

    plt.tight_layout()
    plt.show()

    # 生成300轮的 FLOPs 和 Parameters 列表
    flops_list = [flatten_scalar(v) * FLOPS_SCALE for v in [
        flops_grc,
        flops_grc_freeze_1,
        flops_grc_freeze_2,
        flops_grc_prune_30,
        flops_grc_prune_60,
        flops_grc_brute_prune,
    ]]
    flops_lists_300 = [[v * i for i in range(1, MAX_ROUNDS+1)] for v in flops_list]

    params_list = [flatten_scalar(v) * FLOPS_SCALE * 1000 for v in [
        parameters_grc,
        parameters_grc_freeze_1,
        parameters_grc_freeze_2,
        parameters_grc_prune_30,
        parameters_grc_prune_60,
        parameters_grc_brute_prune,
    ]]
    params_lists_300 = [[v * i for i in range(1, MAX_ROUNDS+1)] for v in params_list]

    acc_smooth_lists = [
        acc_grc_smooth,
        acc_grc_freeze_1_smooth,
        acc_grc_freeze_2_smooth,
        acc_grc_prune_30_smooth,
        acc_grc_prune_60_smooth,
        acc_grc_brute_prune_smooth,
    ]

    # 配色
    color_list = ['tab:blue', 'tab:orange', 'tab:green', 'tab:red', 'tab:purple', 'tab:olive']

    # 第一张图：FLOPs vs Accuracy
    fig, ax = plt.subplots(figsize=(8, 6))
    for flops, acc, label, color in zip(flops_lists_300, acc_smooth_lists, labels_grc, color_list):
        ax.plot(flops, acc, label=label, color=color, alpha=0.8)
    ax.set_xlabel("FLOPs per Round (T)")
    ax.set_ylabel("Accuracy (%)")
    ax.set_title("Accuracy Convergence vs FLOPs")
    ax.grid(True)
    ax.legend()
    plt.tight_layout()
    plt.show()

    # 第二张图：Parameters vs Accuracy
    fig, ax = plt.subplots(figsize=(8, 6))
    for params, acc, label, color in zip(params_lists_300, acc_smooth_lists, labels_grc, color_list):
        ax.plot(params, acc, label=label, color=color, alpha=0.8)
    ax.set_xlabel("Parameters per Round")
    ax.set_ylabel("Accuracy (%)")
    ax.set_title("Accuracy Convergence vs Parameters")
    ax.grid(True)
    ax.legend()
    plt.tight_layout()
    plt.show()

    fig, axes = plt.subplots(figsize=(8, 6))

    axes.plot(acc_1, label='GRA Only', color=colors['GRA Only'])
    axes.fill_between(range(len(acc_1)), acc_1, alpha=0.2, color=colors['GRA Only'])

    axes.plot(acc_2, label='GRA + Freeze 1 Layer', color=colors['Freeze 1'])
    axes.fill_between(range(len(acc_2)), acc_2, alpha=0.2, color=colors['Freeze 1'])

    axes.plot(acc_3, label='GRA + Freeze 2 Layers', color=colors['Freeze 2'])
    axes.fill_between(range(len(acc_3)), acc_3, alpha=0.2, color=colors['Freeze 2'])

    axes.plot(acc_4, label='GRA + Prune 30%', color=colors['Prune 30'])
    axes.fill_between(range(len(acc_4)), acc_4, alpha=0.2, color=colors['Prune 30'])

    axes.plot(acc_5, label='GRA + Prune 60%', color=colors['Prune 60'])
    axes.fill_between(range(len(acc_5)), acc_5, alpha=0.2, color=colors['Prune 60'])

    axes.plot(acc_6, label='GRA + Brute Prune', color=colors['Brute Prune'])
    axes.fill_between(range(len(acc_6)), acc_6, alpha=0.2, color=colors['Brute Prune'])

    axes.set_title("Accuracy vs Rounds")
    axes.set_xlabel("Rounds")
    axes.set_ylabel("Accuracy (%)")
    axes.legend()
    axes.grid(True)

    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    main()