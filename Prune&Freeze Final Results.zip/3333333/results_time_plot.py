"""
This code is used to run the visualisation of the main5 part of the main code, which needs to be run after running main5 and storing the splices in the federated_results_time folder.
The result of the run is a visualisation of the model aggregation effect of time.
"""



import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os

# 定义通用读取函数
def load_metric(load_dir, name):
    path = os.path.join(load_dir, f"{name}.csv")
    if os.path.exists(path):
        return pd.read_csv(path)[name].tolist()
    else:
        print(f"Warning: {name}.csv not found!")
        return []
    
def flatten_scalar(x):
    if isinstance(x, list) and len(x) == 1:
        return x[0]
    return x
def prepend_zero_sum(time_list, acc_list):
    acc_list = list(acc_list)  # 把 pandas.Series 转成 list
    min_len = min(len(time_list), len(acc_list))
    x = [0] + list(np.cumsum(time_list[:min_len]))
    y = [0] + acc_list[:min_len]
    return x, y

def prepend_zero(time_list, acc_list):
    acc_list = list(acc_list)  # 把 pandas.Series 转成 list
    min_len = min(len(time_list), len(acc_list))
    x = [0] + time_list[:min_len]
    y = [0] + acc_list[:min_len]
    return x, y

def main():
    # 设置文件夹路径
    load_dir = "federated_results_time"

    # 读取变量（按照你提供的变量名）
    acc_grc = load_metric(load_dir, "acc_grc")
    acc_grc_smooth = load_metric(load_dir, "acc_grc_smooth")
    comm_grc = load_metric(load_dir, "comm_grc")
    flops_grc = load_metric(load_dir, "flops_grc")
    rounds_grc = load_metric(load_dir, "rounds_grc")
    time_grc = load_metric(load_dir, "time_grc")

    acc_grc_freeze_1 = load_metric(load_dir, "acc_grc_freeze_1")
    acc_grc_freeze_1_smooth = load_metric(load_dir, "acc_grc_freeze_1_smooth")
    comm_grc_freeze_1 = load_metric(load_dir, "comm_grc_freeze_1")
    flops_grc_freeze_1 = load_metric(load_dir, "flops_grc_freeze_1")
    rounds_grc_freeze_1 = load_metric(load_dir, "rounds_grc_freeze_1")
    time_grc_freeze_1 = load_metric(load_dir, "time_grc_freeze_1")

    acc_grc_freeze_2 = load_metric(load_dir, "acc_grc_freeze_2")
    acc_grc_freeze_2_smooth = load_metric(load_dir, "acc_grc_freeze_2_smooth")
    comm_grc_freeze_2 = load_metric(load_dir, "comm_grc_freeze_2")
    flops_grc_freeze_2 = load_metric(load_dir, "flops_grc_freeze_2")
    rounds_grc_freeze_2 = load_metric(load_dir, "rounds_grc_freeze_2")
    time_grc_freeze_2 = load_metric(load_dir, "time_grc_freeze_2")

    acc_grc_prune_30 = load_metric(load_dir, "acc_grc_prune_30")
    acc_grc_prune_30_smooth = load_metric(load_dir, "acc_grc_prune_30_smooth")
    comm_grc_prune_30 = load_metric(load_dir, "comm_grc_prune_30")
    flops_grc_prune_30 = load_metric(load_dir, "flops_grc_prune_30")
    rounds_grc_prune_30 = load_metric(load_dir, "rounds_grc_prune_30")
    time_grc_prune_30 = load_metric(load_dir, "time_grc_prune_30")

    acc_grc_prune_60 = load_metric(load_dir, "acc_grc_prune_60")
    acc_grc_prune_60_smooth = load_metric(load_dir, "acc_grc_prune_60_smooth")
    comm_grc_prune_60 = load_metric(load_dir, "comm_grc_prune_60")
    flops_grc_prune_60 = load_metric(load_dir, "flops_grc_prune_60")
    rounds_grc_prune_60 = load_metric(load_dir, "rounds_grc_prune_60")
    time_grc_prune_60 = load_metric(load_dir, "time_grc_prune_60")

    acc_grc_brute_prune = load_metric(load_dir, "acc_grc_brute_prune")
    acc_grc_brute_prune_smooth = load_metric(load_dir, "acc_grc_brute_prune_smooth")
    comm_grc_brute_prune = load_metric(load_dir, "comm_grc_brute_prune")
    flops_grc_brute_prune = load_metric(load_dir, "flops_grc_brute_prune")
    rounds_grc_brute_prune = load_metric(load_dir, "rounds_grc_brute_prune")
    time_grc_brute_prune = load_metric(load_dir, "time_grc_brute_prune")

    parameters_grc = load_metric(load_dir, "parameters_grc")
    parameters_grc_freeze_1 = load_metric(load_dir, "parameters_grc_freeze_1")
    parameters_grc_freeze_2 = load_metric(load_dir, "parameters_grc_freeze_2")
    parameters_grc_prune_30 = load_metric(load_dir, "parameters_grc_prune_30")
    parameters_grc_prune_60 = load_metric(load_dir, "parameters_grc_prune_60")
    parameters_grc_brute_prune = load_metric(load_dir, "parameters_grc_brute_prune")

    acc_grc_brute_prune_smooth = pd.Series(acc_grc_brute_prune).rolling(window=10, min_periods=1).mean()

    # 配色
    colors = {
        'GRA Only': 'tab:blue',
        'Freeze 1': 'tab:orange',
        'Freeze 2': 'tab:green',
        'Prune 30': 'tab:red',
        'Prune 60': 'tab:purple',
        'Brute Prune': 'tab:olive'
    }

    labels_grc = [
        "GRA Only",
        "GRA + Freeze 1 Layer",
        "GRA + Freeze 2 Layers",
        "GRA + Prune 30%",
        "GRA + Prune 60%",
        "GRA + Brute Prune",
    ]

    flops_values_grc = [flatten_scalar(v) for v in [        
        flops_grc,
        flops_grc_freeze_1,
        flops_grc_freeze_2,
        flops_grc_prune_30,
        flops_grc_prune_60,
        flops_grc_brute_prune,
    ]]

    round_counts_grc = [flatten_scalar(v) for v in [
        rounds_grc,
        rounds_grc_freeze_1,
        rounds_grc_freeze_2,
        rounds_grc_prune_30,
        rounds_grc_prune_60,
        rounds_grc_brute_prune,
    ]]

    parameter_value_grc = [flatten_scalar(v) for v in [
        parameters_grc,
        parameters_grc_freeze_1,
        parameters_grc_freeze_2,
        parameters_grc_prune_30,
        parameters_grc_prune_60,
        parameters_grc_brute_prune,
    ]]

    fig, axes = plt.subplots(1, 3, figsize=(18, 6))
    bar_colors = ['skyblue', 'lightgreen', 'orange']
    metrics = ['FLOPs (TFLOPs)', 'Rounds', 'Params (K)']
    titles = ['FLOPs Comparison', 'Rounds Comparison', 'Parameters Comparison']
    grc_values = [flops_values_grc, round_counts_grc, [p / 1e3 for p in parameter_value_grc]]  # 转为 K 个参数

    for i in range(3):
        bars = axes[i].bar(labels_grc, grc_values[i], color=bar_colors[i % len(bar_colors)])
        for bar in bars:
            height = bar.get_height()
            axes[i].text(bar.get_x() + bar.get_width()/2.0, height, f"{height:.2f}", ha='center', va='bottom')
        axes[i].set_title(titles[i] + " (GRA-based)")
        axes[i].set_ylabel(metrics[i])
        axes[i].tick_params(axis='x', rotation=20)
        axes[i].grid(axis='y', linestyle='--', alpha=0.7)

    plt.tight_layout()
    plt.show()

    fig, axes = plt.subplots(1, 2, figsize=(12, 4))

    # Accuracy Over Time
    axes[0].plot(time_grc, acc_grc, label="GRA Only")
    axes[0].plot(time_grc_brute_prune, acc_grc_brute_prune, label="GRA + Brute Prune")
    axes[0].plot(time_grc_freeze_1, acc_grc_freeze_1, label="GRA + Freeze 1 Layer")
    axes[0].plot(time_grc_freeze_2, acc_grc_freeze_2, label="GRA + Freeze 2 Layers")
    axes[0].plot(time_grc_prune_30, acc_grc_prune_30, label="GRA + Prune 30%")
    axes[0].plot(time_grc_prune_60, acc_grc_prune_60, label="GRA + Prune 60%")
    axes[0].set_title("Accuracy Over Time (GRA)")
    axes[0].set_xlabel("Time")
    axes[0].set_ylabel("Accuracy (%)")
    axes[0].legend()
    axes[0].grid(True)

    # Accuracy vs Communication
    axes[1].plot(comm_grc, acc_grc, label="GRA Only")
    axes[1].plot(comm_grc_brute_prune, acc_grc_brute_prune, label="GRA + Brute Prune")
    axes[1].plot(comm_grc_freeze_1, acc_grc_freeze_1, label="GRA + Freeze 1 Layer")
    axes[1].plot(comm_grc_freeze_2, acc_grc_freeze_2, label="GRA + Freeze 2 Layers")
    axes[1].plot(comm_grc_prune_30, acc_grc_prune_30, label="GRA + Prune 30%")
    axes[1].plot(comm_grc_prune_60, acc_grc_prune_60, label="GRA + Prune 60%")
    axes[1].set_title("Accuracy vs Communication (GRA)")
    axes[1].set_xlabel("Comm Count")
    axes[1].set_ylabel("Accuracy (%)")
    axes[1].legend()
    axes[1].grid(True)

    plt.tight_layout()
    plt.show()

    fig, axes = plt.subplots(1, 2, figsize=(12, 4))

    axes[0].plot(time_grc, acc_grc, color='blue', label="GRA Only", linestyle='--', alpha=0.6)
    axes[0].plot(time_grc, acc_grc_smooth, color='blue', label="GRA Only (Smoothed)")
    axes[0].fill_between(time_grc, acc_grc_smooth, color='blue', alpha=0.2)

    axes[0].plot(time_grc_freeze_1, acc_grc_freeze_1, color='orange', label="GRA + Freeze 1 Layer", linestyle='--', alpha=0.6)
    axes[0].plot(time_grc_freeze_1, acc_grc_freeze_1_smooth, color='orange', label="GRA + Freeze 1 Layer (Smoothed)")
    axes[0].fill_between(time_grc_freeze_1, acc_grc_freeze_1_smooth, color='orange', alpha=0.2)

    axes[0].set_title("Accuracy Over Time")
    axes[0].set_xlabel("Time")
    axes[0].set_ylabel("Accuracy (%)")
    axes[0].legend()
    axes[0].grid(True)

    # 可选另一个子图，如 GRA + Freeze 2
    axes[1].plot(time_grc_freeze_1, acc_grc_freeze_1, label="GRA + Freeze 1 Layer", linestyle='--', alpha=0.6)
    axes[1].plot(time_grc_freeze_1, acc_grc_freeze_1_smooth, label="GRA + Freeze 1 Layer (Smoothed)")
    axes[1].fill_between(time_grc_freeze_1, acc_grc_freeze_1_smooth, color='orange', alpha=0.2)

    axes[1].plot(time_grc_freeze_2, acc_grc_freeze_2, label="GRA + Freeze 2 Layers", linestyle='--', alpha=0.6)
    axes[1].plot(time_grc_freeze_2, acc_grc_freeze_2_smooth, label="GRA + Freeze 2 Layer (Smoothed)")
    axes[1].fill_between(time_grc_freeze_2, acc_grc_freeze_2_smooth, color='green', alpha=0.2)

    axes[1].set_title("Freezing Layers Comparison")
    axes[1].set_xlabel("Time")
    axes[1].set_ylabel("Accuracy (%)")
    axes[1].legend()
    axes[1].grid(True)

    plt.tight_layout()
    plt.show()

    fig, axes = plt.subplots(1, 2, figsize=(12, 4))

    axes[0].plot(time_grc, acc_grc, color='blue', label="GRA Only", linestyle='--', alpha=0.6)
    axes[0].plot(time_grc, acc_grc_smooth, color='blue', label="GRA Only (Smoothed)")
    axes[0].fill_between(time_grc, acc_grc_smooth, color='blue', alpha=0.2)

    axes[0].plot(time_grc_prune_30, acc_grc_prune_30, color='red', label="GRA + Prune 30%", linestyle='--', alpha=0.6)
    axes[0].plot(time_grc_prune_30, acc_grc_prune_30_smooth, color='red', label="GRA + Prune 30% (Smoothed)")
    axes[0].fill_between(time_grc_prune_30, acc_grc_prune_30_smooth, color='red', alpha=0.2)

    axes[0].set_title("Accuracy Over Time")
    axes[0].set_xlabel("Time")
    axes[0].set_ylabel("Accuracy (%)")
    axes[0].legend()
    axes[0].grid(True)

    axes[1].plot(time_grc_prune_30, acc_grc_prune_30, color='red', label="GRA + Prune 30%", linestyle='--', alpha=0.6)
    axes[1].plot(time_grc_prune_30, acc_grc_prune_30_smooth, color='red', label="GRA + Prune 30% (Smoothed)")
    axes[1].fill_between(time_grc_prune_30, acc_grc_prune_30_smooth, color='red', alpha=0.2)

    axes[1].plot(time_grc_prune_60, acc_grc_prune_60, color='purple', label="GRA + Prune 60%", linestyle='--', alpha=0.6)
    axes[1].plot(time_grc_prune_60, acc_grc_prune_60_smooth, color='purple', label="GRA + Prune 60% (Smoothed)")
    axes[1].fill_between(time_grc_prune_60, acc_grc_prune_60_smooth, color='purple', alpha=0.2)

    axes[1].set_title("Pruning Level Comparison")
    axes[1].set_xlabel("Time")
    axes[1].set_ylabel("Accuracy (%)")
    axes[1].legend()
    axes[1].grid(True)

    plt.tight_layout()
    plt.show()

    fig, axes = plt.subplots(1, 2, figsize=(12, 4))

    axes[0].plot(time_grc, acc_grc, label="GRA Only", linestyle='--', color='blue', alpha=0.6)
    axes[0].plot(time_grc, acc_grc_smooth, label="GRA Only (Smoothed)", color='blue')
    axes[0].fill_between(time_grc, acc_grc_smooth, color='blue', alpha=0.2)

    axes[0].plot(time_grc_brute_prune, acc_grc_brute_prune, label="GRA + Brute Prune", linestyle='--', color='olive', alpha=0.6)
    axes[0].plot(time_grc_brute_prune, acc_grc_brute_prune_smooth, label="GRA + Brute Prune (Smoothed)", color='olive')
    axes[0].fill_between(time_grc_brute_prune, acc_grc_brute_prune_smooth, color='olive', alpha=0.2)

    axes[0].set_title("Brute Prune vs Original")
    axes[0].set_xlabel("Rounds")
    axes[0].set_ylabel("Accuracy (%)")
    axes[0].legend()
    axes[0].grid(True)

    axes[1].plot(time_grc_brute_prune, acc_grc_brute_prune, label="GRA + Brute Prune", linestyle='--', color='olive', alpha=0.6)
    axes[1].plot(time_grc_brute_prune, acc_grc_brute_prune_smooth, label="GRA + Brute Prune (Smoothed)", color='olive')
    axes[1].fill_between(time_grc_brute_prune, acc_grc_brute_prune_smooth, color='olive', alpha=0.2)

    axes[1].plot(time_grc_prune_60, acc_grc_prune_60, label="GRA + Prune 60%", linestyle='--', color='purple', alpha=0.6)
    axes[1].plot(time_grc_prune_60, acc_grc_prune_60_smooth, label="GRA + Prune 60% (Smoothed)", color='purple')
    axes[1].fill_between(time_grc_prune_60, acc_grc_prune_60_smooth, color='purple', alpha=0.2)

    axes[1].set_title("Brute Prune vs Prune 60%")
    axes[1].set_xlabel("Rounds")
    axes[1].set_ylabel("Accuracy (%)")
    axes[1].legend()
    axes[1].grid(True)

    plt.tight_layout()
    plt.show()

    # 累积时间 + 加0点
    time_total_1, acc_1 = prepend_zero(time_grc, acc_grc_smooth)
    time_total_2, acc_2 = prepend_zero(time_grc_freeze_1, acc_grc_freeze_1_smooth)
    time_total_3, acc_3 = prepend_zero(time_grc_freeze_2, acc_grc_freeze_2_smooth)
    time_total_4, acc_4 = prepend_zero(time_grc_prune_30, acc_grc_prune_30_smooth)
    time_total_5, acc_5 = prepend_zero(time_grc_prune_60, acc_grc_prune_60_smooth)
    time_total_6, acc_6 = prepend_zero(time_grc_brute_prune, acc_grc_brute_prune_smooth)


    fig, axes = plt.subplots(1, 1, figsize=(8, 6))

    # 配色（可自定义）
    colors = {
        'GRA Only': 'tab:blue',
        'Freeze 1': 'tab:orange',
        'Freeze 2': 'tab:green',
        'Prune 30': 'tab:red',
        'Prune 60': 'tab:purple',
        'Brute Prune': 'tab:olive'
    }

    # 左图：Total Training Time
    axes.plot(time_total_1, acc_1, label='GRA Only', color=colors['GRA Only'])
    axes.fill_between(time_total_1, acc_1, alpha=0.2, color=colors['GRA Only'])

    axes.plot(time_total_2, acc_2, label='GRA + Freeze 1 Layer', color=colors['Freeze 1'])
    axes.fill_between(time_total_2, acc_2, alpha=0.2, color=colors['Freeze 1'])

    axes.plot(time_total_3, acc_3,  label='GRA + Freeze 2 Layers', color=colors['Freeze 2'])
    axes.fill_between(time_total_3, acc_3, alpha=0.2, color=colors['Freeze 2'])

    axes.plot(time_total_4, acc_4, label='GRA + Prune 30%', color=colors['Prune 30'])
    axes.fill_between(time_total_4, acc_4, alpha=0.2, color=colors['Prune 30'])

    axes.plot(time_total_5, acc_5, label='GRA + Prune 60%', color=colors['Prune 60'])
    axes.fill_between(time_total_5, acc_5, alpha=0.2, color=colors['Prune 60'])
    axes.plot(time_total_6, acc_6, label='GRA + Brute Prune', color=colors['Brute Prune'])
    axes.fill_between(time_total_6, acc_6, alpha=0.2, color=colors['Brute Prune'])

    axes.set_title("Accuracy vs Total Training Time")
    axes.set_xlabel("Cumulative Total Time (s)")
    axes.set_ylabel("Accuracy (%)")
    axes.legend()
    axes.grid(True)

    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    main()